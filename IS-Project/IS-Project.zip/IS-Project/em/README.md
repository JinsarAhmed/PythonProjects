# Custom-Email-Application
Made a Python based custom email app with GUI using Tkinter where users can enter their credentials from which you can send either Single or Bulk Emails to the recipient and also add attachments
